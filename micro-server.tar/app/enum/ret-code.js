module.exports = {
  success: 0,
  serverError: 1
}