module.exports = {
  'get /api/getResource.json': 'controller.resource.index',
  'get /api/v1/presentables/auth': 'controller.presentable.queryAuth',
  'get /api/v2/presentables/auth': 'controller.presentable.queryAuth'
}