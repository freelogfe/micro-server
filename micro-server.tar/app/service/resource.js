const Service = require('egg').Service;

class ResourceService extends Service {
  async find() {
    const {ctx} = this
  }
}

module.exports = ResourceService;
