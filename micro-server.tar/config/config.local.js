module.exports = appInfo => {
  const config = {};

  config.httpProxy = {
    target: 'http://112.74.140.101'
  }

  return config;
};
